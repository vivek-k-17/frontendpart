import { NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';


@Component({
  selector: 'app-employee',
  imports: [],
  templateUrl: './employee.component.html',
  styleUrl: './employee.component.css'
})
export class EmployeeComponent  {

//   emp:Employee=new Employee();

//   private baseUrl = 'http://localhost:8080/employeedata';
//  constructor(private http: HttpClient) {}
//   onsubmit() 
//   {
//     this.http.get<Employee>(this.baseUrl).subscribe(
//       (obj)=>{console.log("Data Received "+obj.firstName);this.emp=obj},
//       (error)=>{console.log("We have a problem")}
//     );

    
//   }


}
